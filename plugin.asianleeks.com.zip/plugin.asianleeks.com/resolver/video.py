import re
import requests
import urllib
from models.item import Item
from bs4 import BeautifulSoup


def resolve(url: str) -> str:
    url = urllib.parse.unquote(url)
    r = requests.get(url)
    content = str(r.content)
    rr = re.compile('(?<=href=").*?(?=")')
    m = rr.findall(content)

    for u in m:
        if 'download_filename' in u:
            return u
    return None


def resolveItemsOnPage(url: str) -> str:
    url = urllib.parse.unquote(url)
    r = requests.get(url)
    content = str(r.content)
    res = []

    soup = BeautifulSoup(content, "html.parser")
    items = soup.find_all("div", {"class": "item"})

    for item in items:
        a = item.find('a', recursive=False)
        if not a:
            continue
        img = item.find_all('div', {'class': 'img'})[
            0].find('img', recursive=False)

        href, title = a['href'], a['title']
        thumbnail = img['data-original']

        res.append(Item.ItemBuilder().params(
            {'path': 'load_video', 'url': href, 'name': title}).name(title).image(thumbnail).build())

    return res
