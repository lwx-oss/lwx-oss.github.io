import re
import requests
import urllib


def resolve(url: str) -> str:
    url = urllib.parse.unquote(url)
    r = requests.get(url)
    content = str(r.content)
    rr = re.compile('(?<=href=").*?(?=")')
    m = rr.findall(content)

    for u in m:
        if 'download_filename' in u:
            return u
    return None


def resolveItemsOnPage(url: str) -> str:
    url = urllib.parse.unquote(url)
    r = requests.get(url)
    content = str(r.content)
    rr = re.compile('(?<=href=").*?(?=")')
    m = rr.findall(content)
    res = []
    for u in m:
        if re.match('https://asianleak.com/videos/\d+', u):
            if not u.startswith(url):
                res.append(u)

    return res
