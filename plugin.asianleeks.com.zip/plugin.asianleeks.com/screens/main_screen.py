from lib.router import action, landing_action
from models.item import Item
from models.screen import Screen
from resolver.video import resolve, resolveItemsOnPage
import re

url = 'https://asianleak.com/categories/Singapore/'


def getVideoNameFromUrl(url: str) -> str:
    m = re.match('https://asianleak.com/videos/\d+/(.*)/', url)
    name = m.group(1)[:-1]
    return name


def transformVideoListIntoItemList(videos):
    items = []
    for video in videos:
        item = Item.ItemBuilder().name(getVideoNameFromUrl(video)).description(
            video).params({'path': 'load_video', 'url': video}).build()
        items.append(item)
    return items


@landing_action
def landing_screen(params=None):
    videos = resolveItemsOnPage(url)
    items = transformVideoListIntoItemList(videos)

    screen = Screen(items, 'Select a video')
    return screen


@action
def load_video(params=None):
    url = params['url']
    vid = resolve(url)
    item = Item.ItemBuilder().name('Click Me').to_play(vid).build()
    videos = resolveItemsOnPage(url)
    items = transformVideoListIntoItemList(videos)
    items.insert(0, item)

    screen = Screen(items, 'Select a video')
    return screen
