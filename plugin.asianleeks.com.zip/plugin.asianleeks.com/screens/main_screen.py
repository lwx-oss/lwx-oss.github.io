from lib.router import landing_screen, screen, get_input, playable
from models.item import Item
from models.screen import Screen
from models.playable import Playable
from resolver.video import resolve, resolveItemsOnPage
import time
import re

mappings = {
    'singapore': 'https://xmateur.com/search/Singapore/',
    'popular': 'https://xmateur.com/search/singapore/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=singapore&category_ids=&sort_by=rating&_=' + str(int(time.time()) * 1000),
    'latest': 'https://xmateur.com/search/singapore/?mode=async&function=get_block&block_id=list_videos_videos_list_search_result&q=singapore&category_ids=&sort_by=post_date&_=' + str(int(time.time()) * 1000),
}


def getVideoNameFromUrl(url: str) -> str:
    m = re.match('https://xmateur.com/videos/\d+/(.*)/', url)
    name = m.group(1)[:-1]
    return name


@landing_screen
def landing_screen(params=None):
    items = [
        Item.ItemBuilder()
        .name("Search")
        .description("Search")
        .params("path", "search")
        .build(),

        Item.ItemBuilder()
        .name("Singapore")
        .description("Singapore")
        .params("path", "load_page")
        .params("page", "singapore")
        .build(),

        Item.ItemBuilder()
        .name("Most Popular")
        .description("Most Popular")
        .params("path", "load_page")
        .params("page", "popular")
        .build(),

        Item.ItemBuilder()
        .name("Latest")
        .description("Latest")
        .params("path", "load_page")
        .params("page", "latest")
        .build(),
    ]

    screen = Screen(items, 'Select a video')
    return screen


@screen
def load_page(params):
    page = params['page']
    url = mappings[page]
    items = resolveItemsOnPage(url)

    return Screen(items)


@screen
def load_video(params=None):
    url = params['url']
    item = Item.ItemBuilder().name(
        'Play - {}'.format(params['name'])).playable().params("path", "playVideo").params("url", url).build()
    items = resolveItemsOnPage(url)
    items.insert(0, item)

    screen = Screen(items, 'Select a video')
    return screen


@playable
def playVideo(params):
    url = params['url']
    vid = resolve(url)

    return Playable(url=vid)


@screen
@get_input(prompt="Search", key="searchTerm")
def search(params):
    searchTerm = params['searchTerm']
    searchTerm = searchTerm.replace(' ', '+')
    url = "https://xmateur.com/search/?q={}".format(searchTerm)

    items = resolveItemsOnPage(url)
    screen = Screen(items, 'Select a video')
    return screen
