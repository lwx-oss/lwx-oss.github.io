from lib.router import landing_screen, screen, get_input, playable
from models.item import Item
from models.screen import Screen
from models.playable import Playable
from resolver.video import resolve, resolveItemsOnPage
import re

url = 'https://asianleak.com/categories/Singapore/'


def getVideoNameFromUrl(url: str) -> str:
    m = re.match('https://asianleak.com/videos/\d+/(.*)/', url)
    name = m.group(1)[:-1]
    return name


@landing_screen
def landing_screen(params=None):
    items = resolveItemsOnPage(url)

    screen = Screen(items, 'Select a video')
    return screen


@screen
def load_video(params=None):
    url = params['url']
    item = Item.ItemBuilder().name(
        'Play - {}'.format(params['name'])).playable().params("path", "playVideo").params("url", url).build()
    items = resolveItemsOnPage(url)
    items.insert(0, item)

    screen = Screen(items, 'Select a video')
    return screen


@playable
def playVideo(params):
    url = params['url']
    vid = resolve(url)

    return Playable(url=vid)


@screen
@get_input(prompt="Search", key="searchTerm")
def search(params):
    searchTerm = params['searchTerm']
    searchTerm = searchTerm.replace(' ', '+')
    url = "https://asianleak.com/search/?q={}".format(searchTerm)

    items = resolveItemsOnPage(url)
    screen = Screen(items, 'Select a video')
    return screen
