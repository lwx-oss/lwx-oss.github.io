import requests
import xbmcgui
import re


class ToggleResolver():
    def __init__(self):
        self.userAgent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36'

    def chooseBest(self, jsonResponse):
        filesArray = jsonResponse['Files']
        toPlay = None

        for file in filesArray:
            print('file:', file)
            if file['Format'] == 'HLS_Web_Clear':
                toPlay = file['URL']

        if not toPlay:
            toPlay = filesArray[0]['URL']

        return toPlay

    def resolveChannel5(self):
        headers = {
            'Connection': 'keep-alive',
            'Accept': '*/*',
            'User-Agent': self.userAgent,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Origin': 'https://www.mewatch.sg',
            'Sec-Fetch-Site': 'cross-site',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.mewatch.sg/en/channels/channel-5/316288',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        params = (
            ('m', 'GetMediaInfo'),
        )

        data = '{"initObj":{"Platform":"Web","SiteGuid":"","DomainID":"0","UDID":"","ApiUser":"tvpapi_147","ApiPass":"11111","Locale":{"LocaleLanguage":"","LocaleCountry":"","LocaleDevice":"","LocaleUserState":"Unknown"}},"MediaID":"316288"}'

        response = requests.post('https://tvpapi-as.ott.kaltura.com/v3_9/gateways/jsonpostgw.aspx', headers=headers, params=params, data=data)

        return self.chooseBest(response.json())


    def resolveChannel8(self):
        headers = {
            'Connection': 'keep-alive',
            'Accept': '*/*',
            'User-Agent': self.userAgent,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Origin': 'https://www.mewatch.sg',
            'Sec-Fetch-Site': 'cross-site',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.mewatch.sg/en/channels/channel-8/260581',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        params = (
            ('m', 'GetMediaInfo'),
        )

        data = '{"initObj":{"Platform":"Web","SiteGuid":"","DomainID":"0","UDID":"","ApiUser":"tvpapi_147","ApiPass":"11111","Locale":{"LocaleLanguage":"","LocaleCountry":"","LocaleDevice":"","LocaleUserState":"Unknown"}},"MediaID":"260581"}'

        response = requests.post('https://tvpapi-as.ott.kaltura.com/v3_9/gateways/jsonpostgw.aspx', headers=headers, params=params, data=data)

        return self.chooseBest(response.json())

    def resolveChannelU(self):
        headers = {
            'Connection': 'keep-alive',
            'Accept': '*/*',
            'User-Agent': self.userAgent,
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Origin': 'https://www.mewatch.sg',
            'Sec-Fetch-Site': 'cross-site',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.mewatch.sg/en/channels/channel-u/330332',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        params = (
            ('m', 'GetMediaInfo'),
        )

        data = '{"initObj":{"Platform":"Web","SiteGuid":"","DomainID":"0","UDID":"","ApiUser":"tvpapi_147","ApiPass":"11111","Locale":{"LocaleLanguage":"","LocaleCountry":"","LocaleDevice":"","LocaleUserState":"Unknown"}},"MediaID":"330332"}'

        response = requests.post('https://tvpapi-as.ott.kaltura.com/v3_9/gateways/jsonpostgw.aspx', headers=headers, params=params, data=data)

        return self.chooseBest(response.json())


    def resolveCNA(self):
        return 'https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_5.m3u8'