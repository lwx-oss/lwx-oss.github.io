import requests

def getAllSeries():
    # hardcode all channels since only a few
    content = [
        {'title': 'Channel 5', 'imageURL': 'https://www.mewatch.sg/image/5253176/16x9/947/533/af3ced69a4545a55de38abcbab650fbd/Gs/channel-5.png', 'channel': '5'},
        {'title': 'Channel 8', 'imageURL': 'https://www.mewatch.sg/image/5166818/16x9/947/533/42e7ea2c01e1d100b70b910ab686d1a9/QI/channel-8.png', 'channel': '8'},
        {'title': 'Channel U', 'imageURL': 'https://www.mewatch.sg/image/5308024/16x9/947/533/d51fc06e62ced91d8f8abe3a6a82edb2/NA/channel-u.png', 'channel': 'u'},
        {'title': 'Channel CNA', 'imageURL': 'https://cna-sg-res.cloudinary.com/image/upload/q_auto,f_auto/image/8786976/16x9/991/557/b5725ccd88967cbdbc70aa882ad1c3b5/fk/cna-default-image.png', 'channel': 'cna'}
    ]
    
    return content