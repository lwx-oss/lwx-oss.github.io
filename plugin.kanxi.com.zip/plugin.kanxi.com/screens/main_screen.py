from lib.router import landing_screen, playable
from models.item import Item
from models.playable import Playable
from models.screen import Screen
from resolver.kanxiv import resolveLink, resolveEpisodesOnPage

landing_url = 'https://www.kanxiv.com/play/323300-1-1.html'

@landing_screen
def my_landing(params=None):
    items = resolveEpisodesOnPage(landing_url)

    screen = Screen(items, 'Select a show')
    return screen


@playable
def resolve_and_play_video(params=None):
    url = resolveStream(params['url'])
    return Playable.PlayableBuilder().url(url).build()


def resolveStream(url):
    return resolveLink(url)