import json
import requests
from bs4 import BeautifulSoup
from models.item import Item

BASE_URL = 'https://www.kanxiv.com/'

def resolveLink(url):
    r = requests.get(url)
    print('r.status_code:', r.status_code)
    content = r.content

    soup = BeautifulSoup(content,  "html.parser")
    scripts = soup.findAll('script', type="text/javascript")
    data = scripts[8].contents[0]
    data = data[16:]

    d = json.loads(data)
    return d['url']


def resolveEpisodesOnPage(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.content,  "html.parser")

    episodes = soup.find('ul', {'class': 'stui-play__list clearfix'}).findAll('a')

    items = []
    for episode in episodes:
        items.append(Item.ItemBuilder().name(episode.contents[0]).description(episode.contents[0]).params('url', BASE_URL + episode.get('href')).params('path', 'resolve_and_play_video').build())


    return items