from lib.router import landing_screen, playable, screen
from models.item import Item
from models.screen import Screen
from models.playable import Playable
import uuid
import xml.etree.ElementTree as ET
from urllib.parse import unquote, quote_plus
import requests


BASE_URL = "http://allrss.se/dramas"


def getHeaders(url):
    isVideo = 'http://v.allrss.se' in url
    headers = {
        "UID": uuid.uuid4().hex,
        "VERSION": "2.0",
        "IPADDRESS": "129.31.155.99",
        "User-Agent": "RSS Player/1.2.1 (Android 10)",
        "Host": "v.allrss.se" if isVideo else "allrss.se",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip"
    }

    return headers


def getPage(url):
    headers = getHeaders(url)
    response = requests.get(url, headers=headers)

    root = ET.fromstring(response.content)
    items = root.findall('*/item')

    newItems = []

    for item in items:
        title = item.find('title').text
        description = ""
        descriptionTag = item.find('description')
        if descriptionTag:
            description = descriptionTag.text
        url = item.find('enclosure').attrib['url']
        newItems.append({
            'title': title,
            'url': url,
            'description': description
        })

    return newItems


@landing_screen
def my_landing(params=None):
    page = getPage(BASE_URL)
    items = []

    for item in page:
        items.append(
            Item.ItemBuilder().name(item['title']).params(
                'url', quote_plus(item['url'])).params('path', 'load_page').build()
        )

    screen = Screen(items, 'Select a show')
    return screen


@screen
def load_page(params):
    url = unquote(params['url'])
    isVideo = 'http://v.allrss.se' in url
    page = getPage(url)
    items = []

    for item in page:
        if isVideo:
            items.append(Item.ItemBuilder().name(item['title']).params(
                'url', quote_plus(item['url'])).params('path', 'resolve_and_play_video').playable().build())
        else:
            items.append(
                Item.ItemBuilder().name(item['title']).params(
                    'url', quote_plus(item['url'])).params('path', 'load_page').build()
            )

    screen = Screen(items, 'Select a show')
    return screen


@playable
def resolve_and_play_video(params):
    url = unquote(params['url'])
    return Playable.PlayableBuilder().url(url).build()
