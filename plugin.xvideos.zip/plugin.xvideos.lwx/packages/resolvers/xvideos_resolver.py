import re
import requests


class xVideosResolver():
    def __init__(self):
        self.URL_PREFIX = 'https://www.xvideos.com/'


    def _getPage(self, url):
        r = requests.get(url)

        return r.content



    def getAllVideosInPage(self, pageURL):
        content = self._getPage(pageURL)

        pattern = r'data-src="(.*?)".*(video\d+\/\d+\/\d+\/.*?)".*title="(.*?)"'
        matches = re.findall(pattern, content)

        allVideos = []
        for match in matches:
            video = {
                'title': match[2],
                'URL': self.URL_PREFIX + match[1],
                'imageURL': match[0]
            }
            allVideos.append(video)

        return allVideos


    def getDirectVideoLink(self, videoURL='https://www.xvideos.com/video56621089/16340859/0/big_dick_in_tiny_young_japanese_teen_pussy'):
        content = self._getPage(videoURL)

        pattern = r"setVideoHLS\('(.*?)'\)"
        match = re.search(pattern, content)
        return match.group(1)