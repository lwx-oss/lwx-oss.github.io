GET_ALL_EPISODES_OF_SERIES = 'getAllEpisodesOfSeries'
GET_DIRECT_LINK = 'getDirectLink'
GET_ALL_VIDEO_LINKS = 'getAllVideoLinks'