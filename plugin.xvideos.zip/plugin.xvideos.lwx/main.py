import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urlparse import parse_qsl

from packages.utils import utils
from packages.router import router as internalRouter
from packages.models import DirectoryItem as ItemModel
from packages.builders import ButtonBuilder
from packages.builders import InputBuilder
from packages.builders import ListItemBuilder
from packages.resolvers import xvideos_resolver
from packages.constants import actions_constants

_url = sys.argv[0]

_handle = int(sys.argv[1])

_router = internalRouter.Router()

_screen = xbmcplugin

_settings = xbmcaddon.Addon()


def _getSetting(id):
    return _settings.getSetting(id)

# import web_pdb; web_pdb.set_trace()


class Item():
    def __init__(self):
        pass


def _transformQueryStringIntoDict(queryString):
    d = {}

    for i in queryString:
        d[i[0].replace('?', '')] = i[1]

    return d


def router():
    queryString = parse_qsl(sys.argv[2])
    d = _transformQueryStringIntoDict(queryString)
    action = d['action']

    x = xvideos_resolver.xVideosResolver()
    url = x.getDirectVideoLink(action)

    listItem = xbmcgui.ListItem(path=url)
    listItem.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(_handle, True, listItem)
        


def displayAllVideoLinksForSelection(url):
    _screen.setPluginCategory(_handle, 'Select Video Format')
    _screen.setContent(_handle, 'videos')

    tr = toggle_resolver.ToggleResolver(url)
    item = tr.buildItemDTO()

    listItems = []

    for video in item.videos:
            # needs to be a tuple (url, listItem, isFolder)
        listItem = xbmcgui.ListItem()
        listItem.setLabel(video['format'])
        listItem.setInfo('video', {'title': video['format'], 'mediatype': 'video'})
        isFolder = False # we want to play the actual video link
        listItem.setProperty('IsPlayable', 'true')
        listItem.setSubtitles(item.subtitles)
        listItems.append((video['url'], listItem, isFolder))
    
    _screen.addDirectoryItems(_handle, listItems)
    _screen.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    _screen.endOfDirectory(_handle)


def lazilyResolveAllEpisodesLocally(seriesURL):
    tr = toggle_resolver.SeriesResolver()
    episodes = tr.resolveSeriesToEpisodes(seriesURL)
    _screen.setPluginCategory(_handle, 'Episodes')
    _screen.setContent(_handle, 'videos')
    for episode in episodes:
        episodeName = utils.parseEpisodeURLIntoReadableFormat(episode)
        listItem = xbmcgui.ListItem()
        listItem.setLabel(episodeName)
        listItem.setInfo('video', {
            'title': episodeName,
            'plot': episodeName,
            'mediatype': 'video'
        })

        if isAutoSelectVideoFormat():
            listItem.setProperty('IsPlayable', 'true')
            _screen.addDirectoryItem(
                _handle, '{}?&action={}&url={}'.format(_url, actions_constants.GET_DIRECT_LINK, episode), listItem, False)
        else:
            listItem.setProperty('IsPlayable', 'false')
            _screen.addDirectoryItem(
                _handle, '{}?&action={}&url={}'.format(_url, actions_constants.GET_ALL_VIDEO_LINKS, episode), listItem, True)
    _screen.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    _screen.endOfDirectory(_handle)


def eagerlyResolveAllEpisodesLocally(seriesURL):
    tr = toggle_resolver.SeriesResolver()
    episodes = tr.resolveSeriesToEpisodes(seriesURL)
    _screen.setPluginCategory(_handle, 'Episodes')
    _screen.setContent(_handle, 'videos')
    for episode in episodes:
        tr = toggle_resolver.ToggleResolver(episode)
        if isAutoSelectVideoFormat():
            _screen.addDirectoryItem(
                _handle, tr.getVideoURL(), tr.buildListItem(), False)
        else:
            _screen.addDirectoryItem(
                _handle, '{}?&action={}&url={}'.format(_url, actions_constants.GET_ALL_VIDEO_LINKS, episode), tr.buildListItem(), True)
    _screen.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    _screen.endOfDirectory(_handle)


def resolveAllEpisodesAndShow(url):
    # episodesInfo = resolver.getAllEpisodesOfSeries(url)
    # _screen.setPluginCategory(_handle, 'Episodes')
    # _screen.setContent(_handle, 'videos')
    # for episode in episodesInfo['episodes']:
    #     tr = toggle_resolver.ToggleResolver(episode['url'])
    #     _screen.addDirectoryItem(
    #         _handle, tr.getVideoURL(), tr.buildListItem(), False)
    # _screen.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # _screen.endOfDirectory(_handle)
    pass


def _print(content):
    xbmcgui.Dialog().ok('heading', content)


def retrieve(searchTerm):
    xbmcgui.Dialog().ok('heading', searchTerm)


def landingOptions():
    _screen.setPluginCategory(_handle, 'xVideos')
    _screen.setContent(_handle, 'videos')

    listItems = []

    x = xvideos_resolver.xVideosResolver()
    options = x.getAllVideosInPage(x.URL_PREFIX)

    for option in options:
        imageURL = option['imageURL']
        listItem = xbmcgui.ListItem()
        listItem.setLabel(option['title'])
        # listItem.setArt({})
        listItem.setInfo(
            'video', {'title': option['title'], 'mediatype': 'video'})

        listItem.setArt({
            'thumb': imageURL,
            'icon': imageURL,
            'fanart': imageURL
        })
        
        listItem.setProperty('IsPlayable', 'true')
        isFolder = False
        # needs to become a tuple (url, listItem, isFolder)
        url = '{}?&action={}'.format(
            _url, option['URL'])
        listItems.append((url, listItem, isFolder))

    _screen.addDirectoryItems(_handle, listItems)
    # _screen.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    _screen.endOfDirectory(_handle)


def landing():
    _screen.setPluginCategory(_handle, 'TVB')
    _screen.setContent(_handle, 'videos')

    newsURL = tvb_resolver.getTokenizedLink('66.96.208.137', 1)
    financeURL = tvb_resolver.getTokenizedLink('66.96.208.137', 2)

    episodeName = 'TVB'

    listItem = xbmcgui.ListItem()
    listItem.setLabel(episodeName)
    listItem.setInfo('video', {
            'title': episodeName,
            'plot': episodeName,
            'mediatype': 'video'
        })

    listItem.setProperty('IsPlayable', 'true')
    _screen.addDirectoryItem(
                _handle, newsURL, listItem, False)


    listItem = xbmcgui.ListItem()
    listItem.setLabel(episodeName)
    listItem.setInfo('video', {
            'title': episodeName,
            'plot': episodeName,
            'mediatype': 'video'
        })

    listItem.setProperty('IsPlayable', 'true')
    _screen.addDirectoryItem(
                _handle, financeURL, listItem, False)


    _screen.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    _screen.endOfDirectory(_handle)


def isLazyLoading():
    return _getSetting('lazy-loading') == 'true'

def isAutoSelectVideoFormat():
    return _getSetting('auto-select-video-format') == 'true'


def main():
    action = sys.argv[2]
    if action:
        router()
    landingOptions()

main()