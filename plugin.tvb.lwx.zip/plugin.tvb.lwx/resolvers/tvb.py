import requests
import random

def random_ip_address():
    s = str(random.randint(23, 255))

    for _ in range(3):
        s += '.' + str(random.randint(23, 255))

    return s


def random_device_id():
    ''' 26 char random numbers '''
    s = ''

    while len(s) < 26:
        s += str(random.randint(0, 9))

    return s


def get_tokenized_link(channel: str) -> dict:
    cookies = {
        'tag_deviceid': random_device_id(),
    }

    headers = {
    }

    tvbNewsParams = (
        ('token', 'http://token.tvb.com/stream/live/hls/mobilehd_news_windows1.smil?app=news&feed&client_ip={}'.format(random_ip_address())),
    )

    tvbFinanceParams = (
        ('token', 'http://token.tvb.com/stream/live/hls/mobilehd_finance.smil?app=news&feed&client_ip={}'.format(random_ip_address())),
    )

    params_mapper = {
        'news': tvbNewsParams,
        'finance': tvbFinanceParams
    }

    params = params_mapper[channel]

    response = requests.get('https://news.tvb.com/ajax_call/getVideo.php', headers=headers, params=params, cookies=cookies)

    return response.json()['url']