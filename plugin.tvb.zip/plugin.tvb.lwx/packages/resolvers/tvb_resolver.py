import requests
import random

def randomDeviceId():
    s = ''
    while len(s) < 26:
        s += str(random.randint(0, 9))
    
    return s

def getTokenizedLink(ipAddress='66.96.208.137', channel=1):
    
    cookies = {
        'tag_deviceid': randomDeviceId(),
    }

    headers = {
        'Connection': 'keep-alive',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.96 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'https://news.tvb.com/live/inews',
        'Accept-Language': 'en-US,en;q=0.9',
    }

    tvbNewsParams = (
        ('token', 'http://token.tvb.com/stream/live/hls/mobilehd_news_windows1.smil?app=news&feed&client_ip={}'.format(ipAddress)),
    )

    tvbFinanceParams = (
        ('token', 'http://token.tvb.com/stream/live/hls/mobilehd_finance.smil?app=news&feed&client_ip={}'.format(ipAddress)),
    )

    if channel == 1:
        params = tvbNewsParams
    elif channel == 2:
        params = tvbFinanceParams

    response = requests.get('https://news.tvb.com/ajax_call/getVideo.php', headers=headers, params=params, verify=False, cookies=cookies)

    jsonResp = response.json()
    return jsonResp['url']
